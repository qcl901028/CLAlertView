//
//  ViewController.m
//  AlertView
//
//  Created by hezhijingwei on 16/6/15.
//  Copyright © 2016年 秦传龙. All rights reserved.
//

#import "ViewController.h"
#import "CLAlertView.h"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
   
    self.view.backgroundColor = [UIColor redColor];
    
}


- (IBAction)btn:(id)sender {
    
    CLAlertView *alertView = [[CLAlertView alloc] initWithAlertViewWithTitle:@"说明" text:@"贾老师的会计法哈萨克的积分；爱上当减jadkhf;aejfhlakdjfghlkjdafhg;iqeruhpigquerhpoewjfhgkwejfghlkdjfghkljdsfhgijwehrigpuhqpreiughwreifjgh肥；adpuh aljh ajkldhf ksdjfh sjdfhklasdjfhlajsdhfjalsdhfjlasdhfkajshdfkjashdlfahsdlfaf啊" DefauleBtn:@"确定" cancelBtn:@"取消" defaultBtnBlock:^(UIButton *defaultBtn) {
        
        NSLog(@"%@",defaultBtn.currentTitle);
        
        
    } cancelBtnBlock:^(UIButton *cancelBtn) {
        
        NSLog(@"%@",cancelBtn.currentTitle);
        
    }];
    
    [alertView show];
    
//    [self.view addSubview:alertView];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
