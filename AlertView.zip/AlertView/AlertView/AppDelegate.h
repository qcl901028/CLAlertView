//
//  AppDelegate.h
//  AlertView
//
//  Created by hezhijingwei on 16/6/15.
//  Copyright © 2016年 秦传龙. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

